import time

from viberbot.api.messages import KeyboardMessage, TextMessage, PictureMessage, URLMessage, VideoMessage
from viberbot.api.user_profile import UserProfile

from conf.logger import logger
from database.database import Session
from memes.random_meme import MemeGetterService


def find_handler_for_command(command, sender: UserProfile):
    text = command.text
    logger.info(f"Received command {command} from {sender}")
    if text.lower() == 'start':
        return main_menu()
    if text.lower() == 'send_meme':
        return random_meme(sender)
    if text.lower() == 'send_random_999':
        return random_999(sender)
    else:
        return echo(text)


def echo(message):
    return TextMessage(text=message)


def random_999(sender):
    return URLMessage(media='https://999.md/ru/76390454')


def random_meme(sender):
    try:
        session = Session()
        meme_service = MemeGetterService(session)
        meme = meme_service.get_random_meme(sender)
        retries = 0
        while not meme and retries < 3:
            time.sleep(3)
            meme = meme_service.get_random_meme(sender)
            retries += 1
        if meme:
            if not meme.url.endswith('.gif'):
                return URLMessage(media=meme.url)
            else:
                return VideoMessage(media=meme.url, text='This one is funny')
        return TextMessage(text='Could not find a meme :(')
    except Exception as ex:
        logger.exception(ex)
        return TextMessage(text='Could not find a meme :(')


def main_menu():
    logger.debug('Command to start')
    SAMPLE_KEYBOARD = {
        "Type": "keyboard",
        "Buttons": [
            {
                "Columns": 2,
                "Rows": 1,
                "ActionType": "reply",
                "ActionBody": "send_meme",
                "ReplyType": "message",
                "Text": "Send me a meme!",
            },
            {
                "Columns": 2,
                "Rows": 1,
                "ActionType": "reply",
                "ActionBody": "send_random_999",
                "ReplyType": "message",
                "Text": "Send random 999 post",
            }
        ]
    }

    message = KeyboardMessage(tracking_data='main_menu', keyboard=SAMPLE_KEYBOARD)
    return message


def register():
    pass
