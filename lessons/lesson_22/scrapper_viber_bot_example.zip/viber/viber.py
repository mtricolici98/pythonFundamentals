import json

from viberbot import Api, BotConfiguration

from conf.config import VIBER_API_KEY

bot_configuration = BotConfiguration(
    auth_token=VIBER_API_KEY,
    name='PythonTestBot',
    avatar="http://viber.com/avatar.jpg"
)
viber = Api(bot_configuration)


def set_webhook():
    import requests
    url = 'https://chatapi.viber.com/pa/set_webhook'
    api_key = VIBER_API_KEY
    resp = requests.post(url,
                         data=json.dumps({
                             'url': f'https://viber-bot-test-mtr.herokuapp.com/viber',
                             'is_inline': False,
                             "event_types": [
                                 "delivered",
                                 "seen",
                                 "failed",
                                 "subscribed",
                                 "unsubscribed",
                                 "conversation_started"
                             ]
                         }),
                         headers={'X-Viber-Auth-Token': api_key}
                         )
    print(resp.json())
    print(resp.status_code)
