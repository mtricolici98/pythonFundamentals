def get_random_post():
    pass
