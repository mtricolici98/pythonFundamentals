import os

from sqlalchemy import create_engine, MetaData, text
from sqlalchemy.orm import declarative_base, sessionmaker

uri = os.getenv("DATABASE_URL",
                'postgresql://postgres:root@localhost:5432/database_name_test')  # or other relevant config var
if uri.startswith("postgres://"):
    uri = uri.replace("postgres://", "postgresql://", 1)
engine = create_engine(uri)

schema_name = 'viberbot'

meta = MetaData(engine, schema=schema_name)

with engine.connect() as connection:
    query = text("CREATE SCHEMA IF NOT EXISTS viberbot")
    connection.execute(query)

Base = declarative_base(engine, meta)
Session = sessionmaker(bind=engine)
