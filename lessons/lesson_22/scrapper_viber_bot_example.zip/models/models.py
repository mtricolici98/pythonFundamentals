from datetime import datetime

from sqlalchemy import Column, Integer, String, Date, Text, ForeignKey
from sqlalchemy.orm import relationship

from database.database import Base


class User(Base):
    __tablename__ = 'user'

    id = Column(Integer, primary_key=True, autoincrement=True)
    viber_id = Column(String, unique=True)
    name = Column(String(25), unique=True, nullable=False)
    registration_date = Column(Date(), default=datetime.now)

    def __repr__(self):
        return f"User: [{self.name}, {self.viber_id}, {self.registration_date}]"

    def __str__(self):
        return repr(self)


class Meme(Base):
    __tablename__ = 'meme'

    id = Column(Integer, primary_key=True, autoincrement=True)
    url = Column(Text)


class MemeUser(Base):
    __tablename__ = 'meme_user'

    id = Column(Integer, primary_key=True, autoincrement=True)
    meme_id = Column(Integer, ForeignKey('meme.id'))
    user_id = Column(Integer, ForeignKey('user.id'))
    meme = relationship("Meme", backref="meme_users")
    user = relationship("User", backref="memes")


try:
    Base.metadata.create_all()
except Exception as ex:
    print(ex)
