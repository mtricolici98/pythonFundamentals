from viberbot.api.user_profile import UserProfile

from database.database import Session
from models.models import User


def get_or_create_user_for_viber_id(viber_id, user_data: UserProfile):
    session = Session()
    try:
        user = session.query(User).filter(User.viber_id == viber_id).one()
    except Exception:
        user = User(viber_id=viber_id, name=user_data.name)
        session.add(user)
        session.commit()
    session.close()
    return user
