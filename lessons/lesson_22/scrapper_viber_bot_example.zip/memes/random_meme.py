from random import randint

import requests
from bs4 import BeautifulSoup
from viberbot.api.user_profile import UserProfile

from database.database import Session
from models.models import Meme, MemeUser, User
from services.user_service import get_or_create_user_for_viber_id

MEMES_URL = 'https://old.reddit.com/r/memes/'


class MemeGetterService:

    def __init__(self, session=None):
        if not session:
            session = Session()
        self.session = session

    @staticmethod
    def get_random_request_url():
        return f"{MEMES_URL}?count={randint(0, 1000)}"

    @classmethod
    def extract_memes(cls, data):
        soup = BeautifulSoup(data)
        preview_links = soup.find_all('div', {'class': 'expando'})
        memes = []
        for link in preview_links:
            sub_info = link['data-cachedhtml']
            sub_info_soup = BeautifulSoup(sub_info)
            content = sub_info_soup.find('div', {'class': 'media-preview-content'})
            if not content:
                continue
            if 'video-player' in content.get('class'):
                continue
            img = content.find('a', {'class': 'post-link'})
            if not img:
                continue
            img_href = img.get('href')
            if not img_href:
                continue
            if img_href.endswith(('jpg', 'jpeg', 'gif', 'png')):
                memes.append(img_href)
        if not memes:
            return None
        return memes

    @classmethod
    def get_random_memes(cls):
        data = requests.get(cls.get_random_request_url(), headers={
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36'})
        memes = cls.extract_memes(data.content)
        return memes

    def persist_new_memes(self, memes):
        meme_objs = []
        for meme_url in memes:
            if not self.session.query(Meme).filter(Meme.url == meme_url).count():
                meme_objs.append(Meme(url=meme_url))
        self.session.add_all(meme_objs)
        self.session.commit()
        return meme_objs

    def get_meme_for_user(self, user_id):
        meme = self.session.query(Meme).filter(
            Meme.id.not_in(self.session.query(MemeUser.id).filter(MemeUser.user_id == user_id))).first()
        return meme

    def get_and_persist_new_memes(self):
        memes = self.get_random_memes()
        new_memes = self.persist_new_memes(memes or [])
        return new_memes

    def get_random_meme(self, viber_user):
        user = get_or_create_user_for_viber_id(viber_user.id, viber_user)
        meme = self.get_meme_for_user(user.id)
        if not meme:
            new_memes = self.get_and_persist_new_memes()
            if not new_memes:
                return None
            meme = new_memes[randint(0, len(new_memes) - 1)]
        meme_rel = MemeUser(user_id=user.id, meme_id=meme.id)
        self.session.add(meme_rel)
        self.session.commit()
        return meme


if __name__ == '__main__':
    up = UserProfile('marius', None, '123')
    session = Session()
    print(MemeGetterService(session).get_random_meme(up).url)
