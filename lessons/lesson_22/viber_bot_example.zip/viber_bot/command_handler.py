from viberbot.api.messages import TextMessage, KeyboardMessage
from viberbot.api.user_profile import UserProfile
from viberbot.api.viber_requests import ViberMessageRequest

from weather.weather import weather_for_location


def process_weather_command(message, sender):
    location = message.replace('/weather', '').strip()
    weather_data = weather_for_location(location)
    return TextMessage(text=str(weather_data))


def register_user_food_choice(message, sender):
    print(f'Registering {message} for user {sender.name}')
    if message != 'done':
        return get_food_menu(message, sender)
    else:
        return TextMessage(text='Order placed')


def get_food_menu(message, sender):
    SAMPLE_KEYBOARD = {
        "Type": "keyboard",
        "Buttons": [
            {
                "Columns": 3,
                "Rows": 2,
                "BgColor": "#e6f5ff",
                "ActionType": "reply",
                "ActionBody": "pizza",
                "ReplyType": "message",
                "Text": "Pizza!"
            },
            {
                "Columns": 3,
                "Rows": 2,
                "BgColor": "#e6f5ff",
                "ActionType": "reply",
                "ActionBody": "pasta",
                "ReplyType": "message",
                "Text": "Pasta!"
            },
            {
                "Columns": 3,
                "Rows": 2,
                "BgColor": "#e6f5ff",
                "ActionType": "reply",
                "ActionBody": "salad",
                "ReplyType": "message",
                "Text": "Salad"
            },
            {
                "Columns": 3,
                "Rows": 2,
                "BgColor": "#e6f5ff",
                "ActionType": "reply",
                "ActionBody": "beer",
                "ReplyType": "message",
                "Text": "Beer!"
            },
            {
                "Columns": 3,
                "Rows": 2,
                "BgColor": "#e6f5ff",
                "ActionType": "reply",
                "ActionBody": "done",
                "ReplyType": "message",
                "Text": "Done!"
            },
        ]
    }

    return KeyboardMessage(tracking_data='food_list', keyboard=SAMPLE_KEYBOARD)


def receive_command(message: ViberMessageRequest):
    user_message = message.message.text
    tracking_data = message.message.tracking_data
    if tracking_data == None:
        if user_message.lower().startswith('/weather'):
            return process_weather_command(user_message, message.sender)
        elif user_message.lower().startswith('/menu'):
            return get_food_menu(user_message, message.sender)
        else:
            return TextMessage(text='No such command')
    elif tracking_data == 'food_list':
        return register_user_food_choice(user_message, message.sender)
