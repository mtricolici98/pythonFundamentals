from flask import Flask, request, Response
from viberbot.api.messages.text_message import TextMessage
from viberbot.api.viber_requests import ViberFailedRequest
from viberbot.api.viber_requests import ViberMessageRequest
from viberbot.api.viber_requests import ViberSubscribedRequest

from logger import logger
from viber import viber, set_webhook
from viber_bot.command_handler import receive_command
from weather.weather import get_weather

app = Flask(__name__)


@app.route('/', methods=['GET'])
def main_page():
    return Response(status=200, response='It works')


@app.route('/weather', methods=['GET'])
def weather():
    city = request.args.get('city')
    return Response(status=200, response=dict(data=get_weather(city)))


@app.route('/viber', methods=['POST'])
def incoming():
    logger.debug("received request. post data: {0}".format(request.get_data()))
    # every viber message is signed, you can verify the signature using this method
    if not viber.verify_signature(request.get_data(), request.headers.get('X-Viber-Content-Signature')):
        return Response(status=403)

    # this library supplies a simple way to receive a request object
    viber_request = viber.parse_request(request.get_data())

    if isinstance(viber_request, ViberMessageRequest):
        response = receive_command(viber_request)
        viber.send_messages(viber_request.sender.id, [
            response,
        ])
    elif isinstance(viber_request, ViberSubscribedRequest):
        viber.send_messages(viber_request.get_user.id, [
            TextMessage(text="thanks for subscribing!")
        ])
    elif isinstance(viber_request, ViberFailedRequest):
        logger.warn("client failed receiving message. failure: {0}".format(viber_request))

    return Response(status=200)


@app.before_first_request
def setup_webhook():
    set_webhook()
