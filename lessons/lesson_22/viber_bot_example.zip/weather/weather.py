from dataclasses import dataclass

import requests

url = "https://community-open-weather-map.p.rapidapi.com/weather"


@dataclass
class WeatherData:
    description: str
    temp: str
    feels_like: str
    humidity: str
    wind_speed: str


def get_weather(text):
    headers = {
        "content-type": "application/json",
        "X-RapidAPI-Key": "9fc02c456bmsh6626cffb86bc4a3p13dc03jsn476488b50c4e"
    }
    response = requests.request("GET", url, params={'q': text, 'mode': 'json'}, headers=headers)
    if not response.status_code == 200:
        raise Exception('Couldn\'t load weather')
    return response.json()


def weather_for_location(text):
    data = get_weather(text)
    data = WeatherData(
        data['weather'][0]['main'],
        data['main']['temp'],
        data['main']['feels_like'],
        data['main']['humidity'],
        data['wind']['speed'],
    )
    return data


if __name__ == "__main__":
    weather_for_location('Chisinau, MD')
