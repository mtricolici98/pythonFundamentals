def list_other_posts(user):
    pass


def list_my_posts(user):
    pass


def add_post(user):
    pass


def add_comment(user):
    # Note: Use post ID to identify what post to leave a comment on
    pass


def list_my_comments(user):
    pass


def list_post_comments(user):
    pass


def delete_post(user):
    # Note: Use post ID to identify what post to delete
    pass
